
import { MoveResponse, Player } from '../types';
import { API_BASE_URL } from '../constants';

export const fetchNextMove = async (board: Player[][], aiPlayer: Player): Promise<MoveResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/next_move`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        board: board,
        ai_player: aiPlayer,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Failed to fetch AI move');
    }

    return await response.json();
  } catch (error) {
    console.error('AI API Error:', error);
    throw error;
  }
};
