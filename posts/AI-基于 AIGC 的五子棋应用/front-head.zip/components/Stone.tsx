
import React from 'react';
import { Player } from '../types';

interface StoneProps {
  player: Player;
  isLastMove?: boolean;
}

const Stone: React.FC<StoneProps> = ({ player, isLastMove }) => {
  if (player === Player.EMPTY) return null;

  const isBlack = player === Player.BLACK;
  
  return (
    <div className="relative w-[82%] aspect-square flex items-center justify-center pointer-events-none z-10 scale-0 animate-[scale-in_0.2s_ease-out_forwards]">
      <style>{`
        @keyframes scale-in {
          from { transform: scale(0); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
      `}</style>
      <div 
        className={`w-full h-full rounded-full stone-shadow transition-all duration-300 ${
          isBlack 
            ? 'bg-gradient-to-br from-[#444] via-[#111] to-black shadow-black/40' 
            : 'bg-gradient-to-br from-white via-[#fcfcfc] to-[#d0d0d0] shadow-gray-400/30'
        }`}
      />
      {isLastMove && (
        <div className={`absolute w-2 h-2 rounded-full z-20 ${isBlack ? 'bg-primary shadow-[0_0_8px_rgba(25,127,230,1)]' : 'bg-primary shadow-[0_0_4px_rgba(25,127,230,0.5)]'}`} />
      )}
    </div>
  );
};

export default Stone;
