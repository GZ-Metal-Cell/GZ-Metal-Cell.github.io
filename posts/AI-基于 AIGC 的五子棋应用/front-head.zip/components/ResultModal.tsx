
import React from 'react';
import { Player, Move } from '../types';
import { formatTime } from '../constants';

interface ResultModalProps {
  winner: Player | null;
  movesCount: number;
  time: number;
  onRestart: () => void;
  onReview: () => void;
}

const ResultModal: React.FC<ResultModalProps> = ({ winner, movesCount, time, onRestart, onReview }) => {
  if (winner === null) return null;

  const winnerText = winner === Player.BLACK ? 'Black Wins!' : 'White Wins!';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-white/20 dark:bg-black/40 backdrop-blur-md" />
      <div className="relative w-full max-w-[340px] bg-white dark:bg-background-dark rounded-xl shadow-2xl overflow-hidden border border-gray-100 dark:border-gray-800 flex flex-col items-stretch">
        <div className="flex h-5 w-full items-center justify-center bg-white dark:bg-background-dark border-b border-gray-50 dark:border-gray-800">
          <div className="h-1 w-9 rounded-full bg-[#dce0e5] dark:bg-gray-700"></div>
        </div>
        
        <div className="pt-8 pb-2 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <span className="material-symbols-outlined text-primary text-4xl">emoji_events</span>
            </div>
          </div>
          <h1 className="text-[#111418] dark:text-white tracking-tight text-[32px] font-bold leading-tight px-6">
            {winnerText}
          </h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            A masterful victory in {movesCount} moves.
          </p>
        </div>

        <div className="flex gap-3 p-6 pt-4">
          <div className="flex min-w-[100px] flex-1 flex-col gap-1 rounded-lg p-4 bg-gray-50 dark:bg-gray-800/50 border border-[#dce0e5] dark:border-gray-700">
            <div className="flex items-center gap-1.5 text-gray-500 dark:text-gray-400">
              <span className="material-symbols-outlined text-[18px]">grid_on</span>
              <p className="text-xs font-medium uppercase tracking-wider">Moves</p>
            </div>
            <p className="text-[#111418] dark:text-white tracking-tight text-2xl font-bold">{movesCount}</p>
          </div>
          <div className="flex min-w-[100px] flex-1 flex-col gap-1 rounded-lg p-4 bg-gray-50 dark:bg-gray-800/50 border border-[#dce0e5] dark:border-gray-700">
            <div className="flex items-center gap-1.5 text-gray-500 dark:text-gray-400">
              <span className="material-symbols-outlined text-[18px]">timer</span>
              <p className="text-xs font-medium uppercase tracking-wider">Time</p>
            </div>
            <p className="text-[#111418] dark:text-white tracking-tight text-2xl font-bold">{formatTime(time)}</p>
          </div>
        </div>

        <div className="px-6 pb-2 flex flex-col gap-3">
          <button 
            onClick={onRestart}
            className="flex items-center justify-center rounded-lg h-12 px-5 bg-primary text-white text-base font-bold transition-all shadow-lg shadow-primary/20 hover:scale-[1.02]"
          >
            <span className="material-symbols-outlined mr-2">replay</span>
            Play Again
          </button>
          <button 
            className="flex items-center justify-center rounded-lg h-12 px-5 bg-[#f0f2f4] dark:bg-gray-800 text-[#111418] dark:text-white text-base font-bold"
          >
            <span className="material-symbols-outlined mr-2">share</span>
            Share Result
          </button>
        </div>

        <div className="flex px-4 py-4 justify-center">
          <button 
            onClick={onReview}
            className="flex items-center justify-center rounded-lg h-10 px-4 bg-transparent text-gray-500 dark:text-gray-400 text-sm font-bold hover:text-primary transition-colors"
          >
            <span className="material-symbols-outlined mr-2 text-[18px]">visibility</span>
            Review Game
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultModal;
