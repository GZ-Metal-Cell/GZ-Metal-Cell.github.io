
export enum Player {
  EMPTY = 0,
  BLACK = 1,
  WHITE = 2
}

export interface Move {
  row: number;
  col: number;
  player: Player;
  timestamp: number;
}

export interface GameState {
  board: Player[][];
  currentTurn: Player;
  history: Move[];
  isGameOver: boolean;
  winner: Player | null;
  isAiThinking: boolean;
  gameStartTime: number | null;
  elapsedTime: number;
}

export interface MoveResponse {
  row: number;
  col: number;
}
