
export const BOARD_SIZE = 15;
export const API_BASE_URL = "http://127.0.0.1:8000";

export const formatTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export const getCoordinateLabel = (row: number, col: number): string => {
  const colChar = String.fromCharCode(65 + col); // A, B, C...
  const rowNum = row + 1;
  return `${colChar}${rowNum}`;
};

export const checkWin = (board: number[][], row: number, col: number, player: number): boolean => {
  const directions = [
    [0, 1],  // horizontal
    [1, 0],  // vertical
    [1, 1],  // diagonal
    [1, -1], // anti-diagonal
  ];

  for (const [dr, dc] of directions) {
    let count = 1;
    
    // Positive direction
    let r = row + dr;
    let c = col + dc;
    while (r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE && board[r][c] === player) {
      count++;
      r += dr;
      c += dc;
    }
    
    // Negative direction
    r = row - dr;
    c = col - dc;
    while (r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE && board[r][c] === player) {
      count++;
      r -= dr;
      c -= dc;
    }

    if (count >= 5) return true;
  }
  return false;
};
