
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Player, GameState, Move } from './types';
import { BOARD_SIZE, checkWin, formatTime, getCoordinateLabel } from './constants';
import { fetchNextMove } from './services/api';
import Stone from './components/Stone';
import ResultModal from './components/ResultModal';

const HOSHI_POINTS = [
  [3, 3], [3, 11], [7, 7], [11, 3], [11, 11]
];

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    board: Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(Player.EMPTY)),
    currentTurn: Player.BLACK,
    history: [],
    isGameOver: false,
    winner: null,
    isAiThinking: false,
    gameStartTime: null,
    elapsedTime: 0,
  });

  const [showResult, setShowResult] = useState(false);
  const timerRef = useRef<number | null>(null);

  const restartGame = useCallback(() => {
    setGameState({
      board: Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(Player.EMPTY)),
      currentTurn: Player.BLACK,
      history: [],
      isGameOver: false,
      winner: null,
      isAiThinking: false,
      gameStartTime: Date.now(),
      elapsedTime: 0,
    });
    setShowResult(false);
  }, []);

  useEffect(() => {
    restartGame();
  }, [restartGame]);

  useEffect(() => {
    if (!gameState.isGameOver && gameState.gameStartTime) {
      timerRef.current = window.setInterval(() => {
        setGameState(prev => ({
          ...prev,
          elapsedTime: Math.floor((Date.now() - (prev.gameStartTime || 0)) / 1000)
        }));
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState.isGameOver, gameState.gameStartTime]);

  const makeMove = useCallback((row: number, col: number, player: Player) => {
    setGameState(prev => {
      const newBoard = prev.board.map(r => [...r]);
      newBoard[row][col] = player;
      
      const newMove: Move = { row, col, player, timestamp: Date.now() };
      const newHistory = [...prev.history, newMove];
      const isWin = checkWin(newBoard, row, col, player);
      
      const nextTurn = player === Player.BLACK ? Player.WHITE : Player.BLACK;

      return {
        ...prev,
        board: newBoard,
        history: newHistory,
        currentTurn: isWin ? prev.currentTurn : nextTurn,
        isGameOver: isWin,
        winner: isWin ? player : null,
      };
    });
  }, []);

  const handleCellClick = useCallback(async (row: number, col: number) => {
    if (
      gameState.isGameOver || 
      gameState.isAiThinking || 
      gameState.board[row][col] !== Player.EMPTY ||
      gameState.currentTurn !== Player.BLACK
    ) return;

    makeMove(row, col, Player.BLACK);
  }, [gameState, makeMove]);

  useEffect(() => {
    if (gameState.currentTurn === Player.WHITE && !gameState.isGameOver) {
      const triggerAiMove = async () => {
        setGameState(prev => ({ ...prev, isAiThinking: true }));
        try {
          await new Promise(r => setTimeout(r, 600));
          const aiMove = await fetchNextMove(gameState.board, Player.WHITE);
          makeMove(aiMove.row, aiMove.col, Player.WHITE);
        } catch (err) {
          console.error("AI failed to move:", err);
        } finally {
          setGameState(prev => ({ ...prev, isAiThinking: false }));
        }
      };
      triggerAiMove();
    }
  }, [gameState.currentTurn, gameState.isGameOver, makeMove, gameState.board]);

  useEffect(() => {
    if (gameState.isGameOver) {
      const timer = setTimeout(() => setShowResult(true), 800);
      return () => clearTimeout(timer);
    }
  }, [gameState.isGameOver]);

  const undoMove = () => {
    if (gameState.history.length < 2 || gameState.isAiThinking) return;
    setGameState(prev => {
      const newBoard = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(Player.EMPTY));
      const newHistory = prev.history.slice(0, -2);
      newHistory.forEach(m => { newBoard[m.row][m.col] = m.player; });
      return {
        ...prev,
        board: newBoard,
        history: newHistory,
        currentTurn: Player.BLACK,
        isGameOver: false,
        winner: null,
      };
    });
  };

  const lastMove = gameState.history[gameState.history.length - 1];

  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-[480px] mx-auto overflow-x-hidden border-x border-gray-200 dark:border-gray-800 bg-background-light dark:bg-background-dark">
      <header className="flex items-center bg-white dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-20">
        <div className="text-[#111418] dark:text-white flex size-12 shrink-0 items-center">
          <span className="material-symbols-outlined cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-full transition-colors">arrow_back_ios</span>
        </div>
        <h2 className="text-[#111418] dark:text-white text-lg font-bold leading-tight flex-1 text-center font-display">Gomoku Zen</h2>
        <div className="flex w-12 items-center justify-end">
          <button className="flex items-center justify-center rounded-lg h-12 bg-transparent text-[#111418] dark:text-white transition-colors">
            <span className="material-symbols-outlined">settings_suggest</span>
          </button>
        </div>
      </header>

      <section className="flex flex-wrap gap-3 p-4 z-10">
        <div className="flex min-w-[140px] flex-1 flex-col gap-1 rounded-xl p-4 border border-[#dce0e5] dark:border-gray-700 bg-white dark:bg-gray-900 shadow-sm transition-all duration-300">
          <p className="text-[#637588] dark:text-gray-400 text-xs font-bold uppercase tracking-wider">Turn</p>
          <div className="flex items-center gap-2">
            <div className={`size-4 rounded-full border border-gray-600 stone-shadow transition-colors duration-500 ${gameState.currentTurn === Player.BLACK ? 'bg-black' : 'bg-white'}`}></div>
            <p className="text-[#111418] dark:text-white text-xl font-bold leading-tight">
              {gameState.isGameOver ? (gameState.winner === Player.BLACK ? 'Victory' : 'Defeat') : (gameState.currentTurn === Player.BLACK ? 'Your Turn' : 'AI Thinking')}
            </p>
          </div>
        </div>
        <div className="flex min-w-[140px] flex-1 flex-col gap-1 rounded-xl p-4 border border-[#dce0e5] dark:border-gray-700 bg-white dark:bg-gray-900 shadow-sm">
          <p className="text-[#637588] dark:text-gray-400 text-xs font-bold uppercase tracking-wider">Time</p>
          <p className="text-primary tracking-light text-xl font-bold leading-tight flex items-center gap-2">
            <span className="material-symbols-outlined text-sm">schedule</span>
            {formatTime(gameState.elapsedTime)}
          </p>
        </div>
      </section>

      <main className="px-4 py-2 relative flex justify-center">
        {/* Added 'select-none' to prevent text-selection cursor/highlights during play */}
        <div className="relative w-full max-w-full aspect-square bg-zen-board rounded-sm shadow-xl border-[6px] border-[#6d4c33] flex items-center justify-center overflow-hidden select-none">
          {/* Background Grid Lines */}
          <div className="absolute inset-0" style={{ padding: 'calc(100% / 30)' }}>
            <div className="relative w-full h-full gomoku-grid">
              {HOSHI_POINTS.map(([r, c], i) => (
                <div 
                  key={`hoshi-${i}`} 
                  className="hoshi"
                  style={{ 
                    left: `${(c / 14) * 100}%`, 
                    top: `${(r / 14) * 100}%` 
                  }}
                />
              ))}
            </div>
          </div>
          
          {/* Stone Placement Grid */}
          <div 
            className="absolute inset-0 grid w-full h-full"
            style={{ 
              gridTemplateColumns: `repeat(${BOARD_SIZE}, 1fr)`,
              gridTemplateRows: `repeat(${BOARD_SIZE}, 1fr)`
            }}
          >
            {Array.from({ length: BOARD_SIZE * BOARD_SIZE }).map((_, i) => {
              const r = Math.floor(i / BOARD_SIZE);
              const c = i % BOARD_SIZE;
              const stone = gameState.board[r][c];
              return (
                <div 
                  key={`cell-${r}-${c}`}
                  onClick={() => handleCellClick(r, c)}
                  className="relative w-full h-full cursor-pointer flex items-center justify-center overflow-visible"
                >
                  <Stone 
                    player={stone} 
                    isLastMove={lastMove?.row === r && lastMove?.col === c} 
                  />
                </div>
              );
            })}
          </div>
        </div>
      </main>

      <section className="mt-4 flex flex-col">
        <h4 className="text-[#637588] dark:text-gray-400 text-xs font-bold leading-normal tracking-[0.05em] px-4 py-1 uppercase text-center">Move History</h4>
        <div className="flex gap-3 p-4 overflow-x-auto no-scrollbar scroll-smooth">
          {gameState.history.length === 0 ? (
            <p className="text-gray-400 text-sm italic w-full text-center">Empty board...</p>
          ) : (
            gameState.history.map((move, idx) => (
              <div 
                key={`hist-${idx}`}
                className={`flex h-9 shrink-0 items-center justify-center gap-x-2 rounded-lg border px-4 shadow-sm transition-colors ${
                  idx === gameState.history.length - 1 ? 'bg-primary/10 border-primary/30' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                }`}
              >
                <div className={`size-2 rounded-full ${move.player === Player.BLACK ? 'bg-black' : 'bg-white border border-gray-400'}`}></div>
                <p className={`text-sm font-medium ${idx === gameState.history.length - 1 ? 'text-primary' : 'text-[#111418] dark:text-white'}`}>
                  {idx + 1}. {getCoordinateLabel(move.row, move.col)}
                </p>
              </div>
            ))
          )}
        </div>
      </section>

      <footer className="mt-auto p-6 pb-10 flex gap-4">
        <button 
          onClick={undoMove}
          disabled={gameState.history.length === 0 || gameState.isAiThinking}
          className="flex-1 flex h-14 items-center justify-center gap-2 rounded-xl bg-[#f0f2f4] dark:bg-gray-800 text-[#111418] dark:text-white font-bold transition-all active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <span className="material-symbols-outlined">undo</span>
          Undo
        </button>
        <button 
          onClick={restartGame}
          className="flex-1 flex h-14 items-center justify-center gap-2 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/20 transition-all active:scale-95 hover:bg-primary/90"
        >
          <span className="material-symbols-outlined">refresh</span>
          Restart
        </button>
      </footer>

      <div className={`fixed bottom-24 left-1/2 -translate-x-1/2 transition-all duration-300 ${gameState.isAiThinking ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
        <div className="flex items-center justify-center gap-2 py-2.5 px-6 rounded-full bg-white dark:bg-gray-900 shadow-2xl border border-primary/20">
          <div className="flex gap-1.5">
            <div className="size-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            <div className="size-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
            <div className="size-1.5 bg-primary rounded-full animate-bounce"></div>
          </div>
          <p className="text-xs font-bold text-primary tracking-wide">AI IS ANALYZING</p>
        </div>
      </div>

      {showResult && (
        <ResultModal 
          winner={gameState.winner}
          movesCount={gameState.history.length}
          time={gameState.elapsedTime}
          onRestart={restartGame}
          onReview={() => setShowResult(false)}
        />
      )}
    </div>
  );
};

export default App;
